#!/bin/sh
exec /usr/bin/dotnet /home/owner/share/tmp/sdk_tools/archive-root-0000000000000001/SamsungTvRootAgent.dll 127.0.0.1 8092 /home/owner/share/tmp/sdk_tools/archive-root-0000000000000001/root-agent.token /home/owner/share/tmp/sdk_tools/archive-root-0000000000000001
